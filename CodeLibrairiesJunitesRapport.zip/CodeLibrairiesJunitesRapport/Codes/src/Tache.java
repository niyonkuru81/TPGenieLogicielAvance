public class Tache {

	private int IdTache;
	private String NomTache;
	private String DescriptionTache;
	private String StatusTache;
	
	// constructeurs
	public Tache() {
		
	}

	public Tache(int Idt, String Nomt, String Descriptiont, String Statust) {
		this.IdTache = Idt;
		this.NomTache = Nomt;
		this.DescriptionTache = Descriptiont;
		this.StatusTache = Statust;
	}

	public int getIdt() {
		return IdTache;
	}

	public void setIdt(int Idt) {
		this.IdTache = Idt;
	}

	public String getNomt() {
		return NomTache;
	}

	public void setNomt(String Nomt) {
		this.NomTache = Nomt;
	}

	public String getDescr() {
		return DescriptionTache;
	}

	public void setDescr(String Descr) {
		this.DescriptionTache = Descr;
	}
	

	public String getStatus() {
		return StatusTache;
	}

	public void setStatus(String Statust) {
		this.StatusTache = Statust;
	}
	
	@Override
	public String toString() {
		return "Tache [Idt=" + IdTache + ", Nomt=" + NomTache + " , Descriptiont=" + DescriptionTache + " , Statust=" + StatusTache + "]";
	}
	}