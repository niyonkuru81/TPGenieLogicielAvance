public class Membre {

	private int IdMembre;
	private String NomMembre;
	
	// constructeurs
	public Membre() {
		
	}

	public Membre(int id, String nom) {
		this.IdMembre = id;
		this.NomMembre = nom;
	}

	public int getId() {
		return IdMembre;
	}

	public void setId(int id) {
		this.IdMembre = id;
	}

	public String getNom() {
		return NomMembre;
	}

	public void setNom(String nom) {
		this.NomMembre = nom;
	}

	@Override
	public String toString() {
		return "Membre [id=" + IdMembre + ", nom=" + NomMembre + "]";
	}
}
