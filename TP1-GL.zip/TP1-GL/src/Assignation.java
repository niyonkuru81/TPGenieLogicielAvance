public class Assignation {

	private int IdAssigne;
	private int IdMembre;
	private int IdTache;

	public Assignation(int IdAssigne, int IdMembre, int IdTache) {
		this.IdAssigne = IdAssigne;
		this.IdMembre = IdMembre;
		this.IdTache = IdTache;
	}

	public int getIdAssigne() {
		return IdAssigne;
	}

	public void setIdAssigne(int IdAssigne) {
		this.IdAssigne = IdAssigne;
	}

	public int getIdMembre() {
		return IdMembre;
	}

	public void setIdMembre(int IdMembre) {
		this.IdMembre = IdMembre;
	}

	public int getIdTache() {
		return IdTache;
	}

	public void setIdTache(int IdTache) {
		this.IdTache = IdTache;
	}
}
