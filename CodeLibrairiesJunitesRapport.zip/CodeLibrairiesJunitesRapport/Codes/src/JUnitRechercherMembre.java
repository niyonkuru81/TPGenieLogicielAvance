import static org.junit.Assert.*;

import org.junit.Test;


public class JUnitRechercherMembre {

	@Test
	public void test() {
		Gestionnaire test = new Gestionnaire();
		String nom = "METHODE";
		Membre retour = test.recherche_membre("METHODE");
	}

}
