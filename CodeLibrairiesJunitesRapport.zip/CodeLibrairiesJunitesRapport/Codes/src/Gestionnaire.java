import java.util.ArrayList;
import java.util.Scanner;

public class Gestionnaire {

	/**
	 * @param args
	 */
	static ArrayList<Membre> membres = new ArrayList<>();
	static ArrayList<Tache> taches = new ArrayList<>();
	private static Scanner sc;

	// / Les methodes de la classe membre
	// méthode de recherche d'un membre
	public static Membre recherche_membre(String nom) {
		Membre res = null;
		for (Membre m : membres) {
			if (m.getNom().equalsIgnoreCase(nom)) {
				res = m;
				break;
			}
		}
		return res;
	}

	// méthode de modification d'un membre
	public static void editMembre(int index, String nom) {
		Membre m3 = recherche_membre(nom);
		if (m3 != null) {
			System.out.println("Ce nom existe déjà");
		} else {
			membres.set(index, m3);
		}
	}

	// méthode d'ajout d'un membre
	public static void addMembre(Membre m) {
		Membre m2 = recherche_membre(m.getNom());
		if (m2 != null) {
			System.out.println("Ce nom existe déjà");
		} else {
			m.setId(membres.size()+1);
			membres.add(m);
		}
	}

	// méthode de suppression d'un membre
	public static void delMembre(String nom) {
		Membre m3 = recherche_membre(nom);
		if (m3 != null) {
			membres.remove(m3);
		} else {
			System.out.println("Ce nom n'existe pas déjà");
		}
	}

	// Debut des Methodes de la classe tache
	
	// Recherche d'une tache
	public static Tache recherche_tache(String nom_tache) {
		Tache res = null;
		for (Tache t : taches) {
			if (t.getNomt().equalsIgnoreCase(nom_tache)) {
				res = t;
				break;
			}
		}
		return res;
	}

	// méthode de modification d'une tache
	public static void editTache(int index, String nomt) {
		Tache t = recherche_tache(nomt);
		if (t != null) {
			System.out.println("Cette tache existe déjà");
		} else {
			taches.set(index, t);
		}
	}

	// méthode d'ajout d'une tache
	public void addTache(Tache t) {
		Tache t2 = recherche_tache(t.getNomt());
		if (t2 != null) {
			System.out.println("Cette tache existe déjà");
		} else {
			taches.add(t);
		}
	}

	// méthode de suppression d'un membre
	public void delTache(String nom) {
		Membre t3 = recherche_membre(nom);
		if (t3 != null) {
			taches.remove(t3);
		} else {
			System.out.println("Suppression de la tache avec succès");
		}
	}

	public static void menu() {
		System.out.println("1 : Créer un membre");
		System.out.println("2 : Rechercher un membre");
		System.out.println("3 : Modifier un membre");
		System.out.println("4 : Supprimer un membre");
		System.out.println("5 : Créer une tâche");
		System.out.println("6 : Supprimer une tâche ");
		System.out.println("7 : Assigner une tâche à un membre");
		System.out.println("Q ou q : Quitter le programme");
	}

	// / fin des methodes de la classe tache

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nom = "";
		String choix = "";
		sc = new Scanner(System.in);
		do {
			menu();
			//Ajouter un membre
			System.out.print("Veuillez choisir une option : ");
			choix = sc.nextLine();
			if (choix.equals("1")) {
				System.out.print("Veuillez saisir le nom du nouveau membre : ");
				nom = sc.nextLine();
				addMembre(new Membre(0, nom));
				// Rechercher et afficher un membre
			} else if (choix.equals("2")) {
				System.out.print("Veuillez saisir le nom du membre à rechercher : ");
				nom = sc.nextLine();
				Membre m2 = recherche_membre(nom);
				if (m2 != null)
					System.out.println(m2.toString());
				else
					System.out.println("Ce nom n'existe pas!");
				
				// Modifier un membre
			} else if (choix.equals("3")) {
				System.out.print("Veuillez saisir le nom du membre à modifier : ");
				nom = sc.nextLine();
				Membre m3 = recherche_membre(nom);
				if (m3 != null) {
					System.out.println(" veuillez entrer les modifications");
					nom = sc.nextLine();
					System.out.println(" modifications enregistrees");
				} else {
					System.out.println(" Ce nom n'existe pas");
				}
		
				
			} 
			else if (choix.equals("4")) {
				System.out.print("Veuillez saisir le nom du membre a supprimer: ");
				nom = sc.nextLine();
				delMembre(nom);
				
			}
			
			// Ajout tache
			else if (choix.equals("5")) {
				System.out.print("Veuillez saisir le nom de la tache : ");
				nom = sc.nextLine();
				
			}
			else if (choix.equals("6")) {
				String tache_name;
				System.out.print("Veuillez choisir la tache a Supprimer : ");
				tache_name = sc.nextLine();
				if (tache_name!= null) {
				System.out.print("Suppression de la tâche "+ tache_name);
				System.out.print("\n********\n");
				}
				else {
					System.out.print(" Cette tâche n' existe pas");
					System.out.println("\n********** \n");
				}
				
			}
			else if (choix.equals("7")) {
				String tache2;
				String member1;
				System.out.print("Veuillez saisir nom de la tache à assigner à un membre : ");
				member1 = sc.nextLine();
				System.out.print("Veuillez saisir le membre: ");
				tache2 = sc.nextLine();
				System.out.println("**** La tache : "  +member1);
				System.out.println("est assignée à :"  +tache2);
				System.out.println("\n********** \n");
			
					
			}
			
			else{
				System.out.println("\n*** Mauvaise option ***\n");
			}
		} while (!choix.toUpperCase().equals("Q")); // q == pour quitter le programme
	}
}
